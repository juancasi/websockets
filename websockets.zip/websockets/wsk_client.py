#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 27 01:42:45 2018

@author: juancastro
"""

# WS client example for old Python versions

import asyncio
import websockets

@asyncio.coroutine
def hello():
    websocket = yield from websockets.connect(
        'ws://localhost:5678/')

    try:
        """
        name = input("What's your name? ")

        yield from websocket.send(name)
        print("> {}".format(name))
        """
        greeting = yield from websocket.recv()
        print("< {}".format(greeting))

    finally:
        yield from websocket.close()

while True:
    asyncio.get_event_loop().run_until_complete(hello())
    #asyncio.get_event_loop().run_forever()
    



